export const MailConfig = {
    hostname: 'smtp.gmail.com',
    username: 'sami-upisite-svoj-username',
    password: 'sami-upisite-svoj-password',
    senderEmail: 'vas-username@domen.tld',
    
    orderNotificationMail: 'kome-se-salje-kopija@firma.tld'
}