export const DatabaseConfiguration = {
    hostname : 'localhost',
    username : 'aplikacija',
    password : 'aplikacija',
    database : 'aplikacija'
};