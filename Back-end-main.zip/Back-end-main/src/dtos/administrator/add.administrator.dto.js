"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddAdministratorDto = void 0;
class AddAdministratorDto {
}
exports.AddAdministratorDto = AddAdministratorDto;
//# sourceMappingURL=add.administrator.dto.js.map