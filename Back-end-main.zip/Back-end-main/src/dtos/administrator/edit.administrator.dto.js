"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EditAdministratorDto = void 0;
class EditAdministratorDto {
}
exports.EditAdministratorDto = EditAdministratorDto;
//# sourceMappingURL=edit.administrator.dto.js.map